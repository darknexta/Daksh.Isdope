// ============================================
// PERSONAL PORTFOLIO - CUSTOMIZABLE DATA CONFIG
// ============================================
// Edit this file to customize your portfolio website
// All content is centralized here for easy editing

export interface ProfileData {
  // Personal Info
  name: string;
  firstName: string;
  lastName: string;
  title: string;
  location: string;
  email: string;

  // Hero Section
  hero: {
    greeting: string;
    subtitle: string;
    description: string;
    portraitImage: string;
  };

  // About Section
  about: {
    heading: string;
    paragraphs: string[];
    ctaText: string;
    ctaLink: string;
    portraitImage: string;
  };

  // Experience Section
  experience: {
    heading: string;
    subtitle: string;
    jobs: {
      company: string;
      role: string;
      period: string;
      description: string;
      logo?: string;
    }[];
  };

  // Projects/Works Section
  projects: {
    heading: string;
    subtitle: string;
    items: {
      title: string;
      category: string;
      year: string;
      image: string;
      featured?: boolean;
      link?: string;
    }[];
  };

  // Skills Section
  skills: {
    heading: string;
    subtitle: string;
    categories: {
      name: string;
      skills: string[];
    }[];
  };

  // Footer/Contact Section
  footer: {
    ctaHeading: string;
    ctaSubtext: string;
    ctaButton: string;
    socials: {
      name: string;
      url: string;
      icon: string;
    }[];
    copyright: string;
  };
}

// ============================================
// EDIT YOUR DATA HERE
// ============================================

export const profileData: ProfileData = {
  // Personal Info
  name: "Alex Turner",
  firstName: "Alex",
  lastName: "Turner",
  title: "Senior Product Designer",
  location: "San Francisco, CA",
  email: "hello@alexturner.design",

  // Hero Section
  hero: {
    greeting: "Hi, I'm",
    subtitle: "A Senior Product Designer",
    description:
      "Currently helping teams build better products at Google. Previously shaping experiences at Apple and Meta.",
    portraitImage:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1000&fit=crop&crop=face",
  },

  // About Section
  about: {
    heading: "About Me",
    paragraphs: [
      "I'm a product designer with over 8 years of experience crafting digital experiences that matter. My approach combines strategic thinking with meticulous attention to detail.",
      "I believe great design is invisible—it just works. Every pixel, every interaction, every moment should feel intentional and effortless.",
      "When I'm not designing, you'll find me exploring photography, reading about cognitive psychology, or hiking through nature with my camera.",
    ],
    ctaText: "Download Resume",
    ctaLink: "#",
    portraitImage:
      "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=1200&h=800&fit=crop&crop=face",
  },

  // Experience Section
  experience: {
    heading: "Experience",
    subtitle: "A journey through my professional career",
    jobs: [
      {
        company: "Google",
        role: "Senior Product Designer",
        period: "2021 - Present",
        description:
          "Leading design for Google Workspace collaboration tools. Driving design systems and mentoring junior designers.",
      },
      {
        company: "Apple",
        role: "Product Designer",
        period: "2018 - 2021",
        description:
          "Designed experiences for iOS and macOS applications. Collaborated with engineering to ship pixel-perfect interfaces.",
      },
      {
        company: "Meta",
        role: "UI/UX Designer",
        period: "2016 - 2018",
        description:
          "Created user interfaces for Facebook Business products. Conducted user research and usability testing.",
      },
      {
        company: "IDEO",
        role: "Junior Designer",
        period: "2014 - 2016",
        description:
          "Started my career working on diverse client projects. Learned the fundamentals of human-centered design.",
      },
    ],
  },

  // Projects Section
  projects: {
    heading: "Selected Works",
    subtitle: "A collection of projects I'm proud of",
    items: [
      {
        title: "Bloom Finance App",
        category: "Mobile Design",
        year: "2024",
        image:
          "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=1600&h=800&fit=crop",
        featured: true,
        link: "#",
      },
      {
        title: "Horizon Dashboard",
        category: "Web Application",
        year: "2023",
        image:
          "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&h=600&fit=crop",
        link: "#",
      },
      {
        title: "Aura Brand Identity",
        category: "Branding",
        year: "2023",
        image:
          "https://images.unsplash.com/photo-1600607686527-6fb886090705?w=800&h=600&fit=crop",
        link: "#",
      },
      {
        title: "Pulse Health Tracker",
        category: "Product Design",
        year: "2022",
        image:
          "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop",
        link: "#",
      },
      {
        title: "Echo Music Platform",
        category: "UX Design",
        year: "2022",
        image:
          "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=800&h=600&fit=crop",
        link: "#",
      },
    ],
  },

  // Skills Section
  skills: {
    heading: "Skills & Expertise",
    subtitle: "Tools and technologies I work with",
    categories: [
      {
        name: "Design",
        skills: ["UI/UX Design", "Visual Design", "Design Systems", "Prototyping", "User Research"],
      },
      {
        name: "Tools",
        skills: ["Figma", "Sketch", "Adobe Creative Suite", "Principle", "Framer"],
      },
      {
        name: "Development",
        skills: ["HTML/CSS", "JavaScript", "React", "Tailwind CSS", "Git"],
      },
    ],
  },

  // Footer Section
  footer: {
    ctaHeading: "Let's work together",
    ctaSubtext: "Have a project in mind? Let's create something amazing.",
    ctaButton: "Get in Touch",
    socials: [
      {
        name: "Twitter",
        url: "https://twitter.com",
        icon: "twitter",
      },
      {
        name: "LinkedIn",
        url: "https://linkedin.com",
        icon: "linkedin",
      },
      {
        name: "Dribbble",
        url: "https://dribbble.com",
        icon: "dribbble",
      },
      {
        name: "Instagram",
        url: "https://instagram.com",
        icon: "instagram",
      },
    ],
    copyright: "© 2024 Alex Turner. All rights reserved.",
  },
};

export default profileData;
