import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';
import { Mail, MapPin, Twitter, Linkedin, Dribbble, Instagram } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  twitter: <Twitter size={20} />,
  linkedin: <Linkedin size={20} />,
  dribbble: <Dribbble size={20} />,
  instagram: <Instagram size={20} />,
};

const Footer = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate content elements
            if (contentRef.current) {
              const elements = contentRef.current.querySelectorAll('.animate-item');
              elements.forEach((el, i) => {
                setTimeout(() => {
                  (el as HTMLElement).style.opacity = '1';
                  (el as HTMLElement).style.transform = 'translateY(0) scale(1)';
                }, 100 + i * 100);
              });
            }

            observer.disconnect();
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const { ctaHeading, ctaSubtext, ctaButton, socials, copyright } = profileData.footer;
  const { email, location } = profileData;

  return (
    <footer
      ref={sectionRef}
      id="contact"
      className="relative w-full py-24 lg:py-32"
      style={{
        background: 'linear-gradient(to bottom, var(--bg-primary), var(--bg-secondary))',
      }}
    >
      {/* Subtle Particle Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 rounded-full bg-white/10"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${4 + Math.random() * 4}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
      </div>

      <div className="relative z-10 w-full section-padding">
        <div ref={contentRef} className="max-w-[900px] mx-auto text-center">
          {/* CTA Heading */}
          <h2
            className="animate-item text-white mb-6"
            style={{
              opacity: 0,
              transform: 'translateY(40px) scale(0.9)',
              transition: 'all 0.7s var(--ease-out-expo)',
            }}
          >
            {ctaHeading}
          </h2>

          {/* CTA Subtext */}
          <p
            className="animate-item text-[var(--text-muted)] text-lg md:text-xl mb-10 max-w-lg mx-auto"
            style={{
              opacity: 0,
              transform: 'translateY(20px)',
              transition: 'all 0.5s var(--ease-out-quart)',
            }}
          >
            {ctaSubtext}
          </p>

          {/* CTA Button */}
          <div
            className="animate-item mb-16"
            style={{
              opacity: 0,
              transform: 'scale(0.8)',
              transition: 'all 0.4s var(--ease-elastic)',
            }}
          >
            <a
              href={`mailto:${email}`}
              className="btn-primary text-lg px-10 py-5 inline-flex items-center gap-3 group"
              style={{
                animation: 'pulseGlow 3s ease-in-out infinite',
              }}
            >
              <Mail size={20} />
              <span>{ctaButton}</span>
            </a>
          </div>

          {/* Contact Info */}
          <div
            className="animate-item flex flex-wrap justify-center gap-8 mb-12"
            style={{
              opacity: 0,
              transform: 'translateY(15px)',
              transition: 'all 0.3s var(--ease-out-quart)',
            }}
          >
            <a
              href={`mailto:${email}`}
              className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-white transition-colors duration-300"
            >
              <Mail size={18} />
              <span>{email}</span>
            </a>
            <div className="flex items-center gap-2 text-[var(--text-secondary)]">
              <MapPin size={18} />
              <span>{location}</span>
            </div>
          </div>

          {/* Social Links */}
          <div
            className="animate-item flex justify-center gap-4 mb-16"
            style={{
              opacity: 0,
              transform: 'translateY(15px)',
              transition: 'all 0.3s var(--ease-out-quart)',
            }}
          >
            {socials.map((social, index) => (
              <a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-12 h-12 rounded-full border border-[var(--border-subtle)] flex items-center justify-center text-[var(--text-secondary)] hover:text-white hover:border-[var(--border-hover)] hover:scale-115 hover:rotate-[10deg] transition-all duration-200"
                style={{
                  transitionTimingFunction: 'var(--ease-elastic)',
                }}
                aria-label={social.name}
              >
                {iconMap[social.icon] || <span className="text-xs">{social.name[0]}</span>}
              </a>
            ))}
          </div>

          {/* Divider */}
          <div
            className="animate-item w-full h-px bg-gradient-to-r from-transparent via-[var(--border-subtle)] to-transparent mb-8"
            style={{
              opacity: 0,
              transition: 'opacity 0.4s var(--ease-smooth)',
            }}
          />

          {/* Copyright */}
          <p
            className="animate-item text-[var(--text-muted)] text-sm"
            style={{
              opacity: 0,
              transition: 'opacity 0.4s var(--ease-smooth)',
            }}
          >
            {copyright}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
