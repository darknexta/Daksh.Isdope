import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';

const Hero = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const nameRef = useRef<HTMLDivElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const descRef = useRef<HTMLParagraphElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Entrance animations
    const ctx = new (window as any).IntersectionObserver(
      (entries: IntersectionObserverEntry[]) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate name letters
            if (nameRef.current) {
              const letters = nameRef.current.querySelectorAll('.name-letter');
              letters.forEach((letter, i) => {
                setTimeout(() => {
                  (letter as HTMLElement).style.opacity = '1';
                  (letter as HTMLElement).style.transform = 'translateY(0) rotateX(0deg)';
                }, 400 + i * 50);
              });
            }

            // Animate subtitle
            setTimeout(() => {
              if (subtitleRef.current) {
                subtitleRef.current.style.opacity = '1';
                subtitleRef.current.style.transform = 'translateX(0)';
              }
            }, 900);

            // Animate description
            setTimeout(() => {
              if (descRef.current) {
                descRef.current.style.opacity = '1';
                descRef.current.style.transform = 'translateY(0)';
              }
            }, 1100);

            // Animate image
            setTimeout(() => {
              if (imageRef.current) {
                imageRef.current.style.opacity = '1';
                imageRef.current.style.transform = 'scale(1)';
              }
            }, 600);

            ctx.disconnect();
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      ctx.observe(sectionRef.current);
    }

    return () => ctx.disconnect();
  }, []);

  const { firstName, lastName } = profileData;
  const { greeting, subtitle, description, portraitImage } = profileData.hero;

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen w-full flex items-center overflow-hidden"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Animated Background Gradient */}
      <div
        className="absolute inset-0 opacity-60"
        style={{
          background: `
            radial-gradient(ellipse at 20% 30%, rgba(24, 24, 34, 0.8) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 70%, rgba(15, 15, 26, 0.6) 0%, transparent 50%),
            linear-gradient(180deg, var(--bg-primary) 0%, var(--bg-secondary) 100%)
          `,
        }}
      />

      {/* Subtle Noise Overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      {/* Content Container */}
      <div className="relative z-10 w-full section-padding py-20 lg:py-0">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center max-w-[1600px] mx-auto">
          {/* Left Column - Text Content */}
          <div className="order-2 lg:order-1 flex flex-col justify-center">
            {/* Greeting */}
            <p
              className="text-lg md:text-xl text-[var(--text-muted)] mb-2 font-light tracking-wide"
              style={{
                opacity: 0,
                animation: 'fadeInUp 0.6s var(--ease-out-expo) 0.2s forwards',
              }}
            >
              {greeting}
            </p>

            {/* Name */}
            <div
              ref={nameRef}
              className="mb-6"
              style={{ perspective: '1000px' }}
            >
              <h1 className="text-white leading-none">
                {/* First Name */}
                <span className="block overflow-hidden">
                  {firstName.split('').map((letter, i) => (
                    <span
                      key={`first-${i}`}
                      className="name-letter inline-block"
                      style={{
                        opacity: 0,
                        transform: 'translateY(80px) rotateX(45deg)',
                        transition: 'all 0.8s var(--ease-out-expo)',
                        transitionDelay: `${400 + i * 50}ms`,
                      }}
                    >
                      {letter}
                    </span>
                  ))}
                </span>
                {/* Last Name */}
                <span className="block overflow-hidden mt-2">
                  {lastName.split('').map((letter, i) => (
                    <span
                      key={`last-${i}`}
                      className="name-letter inline-block"
                      style={{
                        opacity: 0,
                        transform: 'translateY(80px) rotateX(45deg)',
                        transition: 'all 0.8s var(--ease-out-expo)',
                        transitionDelay: `${550 + i * 50}ms`,
                      }}
                    >
                      {letter}
                    </span>
                  ))}
                </span>
              </h1>
            </div>

            {/* Subtitle */}
            <p
              ref={subtitleRef}
              className="text-xl md:text-2xl lg:text-3xl text-[var(--text-secondary)] font-light mb-6"
              style={{
                opacity: 0,
                transform: 'translateX(-40px)',
                transition: 'all 0.6s var(--ease-out-quart)',
              }}
            >
              {subtitle}
            </p>

            {/* Description */}
            <p
              ref={descRef}
              className="text-base md:text-lg text-[var(--text-muted)] max-w-lg leading-relaxed"
              style={{
                opacity: 0,
                transform: 'translateY(30px)',
                transition: 'all 0.5s var(--ease-out-quart)',
              }}
            >
              {description}
            </p>

            {/* CTA Buttons */}
            <div
              className="flex flex-wrap gap-4 mt-10"
              style={{
                opacity: 0,
                animation: 'fadeInUp 0.6s var(--ease-out-quart) 1.3s forwards',
              }}
            >
              <a href="#contact" className="btn-primary">
                Get in Touch
              </a>
              <a href="#works" className="btn-secondary">
                View My Work
              </a>
            </div>
          </div>

          {/* Right Column - Portrait Image */}
          <div className="order-1 lg:order-2 flex justify-center lg:justify-end">
            <div
              ref={imageRef}
              className="relative"
              style={{
                opacity: 0,
                transform: 'scale(1.15)',
                transition: 'all 1s var(--ease-out-expo)',
              }}
            >
              {/* Image Container with Glow */}
              <div className="relative group">
                {/* Glow Effect */}
                <div
                  className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{
                    background: 'radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, transparent 70%)',
                    filter: 'blur(40px)',
                    transform: 'scale(1.2)',
                  }}
                />

                {/* Portrait Image */}
                <div
                  className="relative w-[280px] h-[350px] md:w-[350px] md:h-[440px] lg:w-[400px] lg:h-[500px] rounded-3xl overflow-hidden"
                  style={{
                    boxShadow: '0 25px 80px rgba(0, 0, 0, 0.5)',
                  }}
                >
                  <img
                    src={portraitImage}
                    alt={`${firstName} ${lastName}`}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    style={{
                      animation: 'float 6s ease-in-out infinite',
                    }}
                  />

                  {/* Subtle Overlay */}
                  <div
                    className="absolute inset-0 bg-gradient-to-t from-[var(--bg-primary)]/30 via-transparent to-transparent"
                  />
                </div>

                {/* Decorative Elements */}
                <div
                  className="absolute -bottom-4 -right-4 w-24 h-24 rounded-full border border-[var(--border-subtle)] opacity-50"
                  style={{
                    animation: 'float 8s ease-in-out infinite reverse',
                  }}
                />
                <div
                  className="absolute -top-6 -left-6 w-16 h-16 rounded-full border border-[var(--border-subtle)] opacity-30"
                  style={{
                    animation: 'float 10s ease-in-out infinite',
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{
          background: 'linear-gradient(to top, var(--bg-primary), transparent)',
        }}
      />
    </section>
  );
};

export default Hero;
