import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';
import { Download } from 'lucide-react';

const About = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate image
            if (imageRef.current) {
              imageRef.current.style.opacity = '1';
              imageRef.current.style.transform = 'scale(1)';
              imageRef.current.style.clipPath = 'inset(0)';
            }

            // Animate content
            if (contentRef.current) {
              const elements = contentRef.current.querySelectorAll('.animate-item');
              elements.forEach((el, i) => {
                setTimeout(() => {
                  (el as HTMLElement).style.opacity = '1';
                  (el as HTMLElement).style.transform = 'translateY(0)';
                }, 400 + i * 150);
              });
            }

            // Animate decorative line
            if (lineRef.current) {
              setTimeout(() => {
                const length = lineRef.current?.getTotalLength() || 0;
                if (lineRef.current) {
                  lineRef.current.style.strokeDasharray = `${length}`;
                  lineRef.current.style.strokeDashoffset = '0';
                }
              }, 300);
            }

            observer.disconnect();
          }
        });
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const { heading, paragraphs, ctaText, ctaLink, portraitImage } = profileData.about;

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative min-h-screen w-full flex items-center py-20 lg:py-0"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Decorative SVG Line */}
      <svg
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none hidden lg:block"
        style={{ zIndex: 1 }}
      >
        <path
          ref={lineRef}
          d="M 45% 50% Q 50% 50% 55% 50%"
          fill="none"
          stroke="rgba(255, 255, 255, 0.1)"
          strokeWidth="1"
          style={{
            strokeDasharray: '1000',
            strokeDashoffset: '1000',
            transition: 'stroke-dashoffset 0.8s var(--ease-out-quart)',
          }}
        />
      </svg>

      <div className="relative z-10 w-full section-padding">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center max-w-[1600px] mx-auto">
          {/* Left Column - Image */}
          <div className="relative">
            <div
              ref={imageRef}
              className="relative overflow-hidden rounded-2xl lg:rounded-3xl"
              style={{
                opacity: 0,
                transform: 'scale(1.2)',
                clipPath: 'inset(0 100% 0 0)',
                transition: 'all 1s var(--ease-out-expo)',
              }}
            >
              {/* Image */}
              <div
                className="aspect-[4/3] lg:aspect-[3/2]"
                style={{
                  transform: 'perspective(1000px) rotateY(-3deg)',
                  transition: 'transform 0.6s ease-out',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'perspective(1000px) rotateY(0deg) scale(1.02)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'perspective(1000px) rotateY(-3deg)';
                }}
              >
                <img
                  src={portraitImage}
                  alt="About"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-tr from-[var(--bg-primary)]/20 via-transparent to-[var(--bg-primary)]/10" />
            </div>

            {/* Decorative Frame */}
            <div
              className="absolute -bottom-4 -right-4 w-full h-full border border-[var(--border-subtle)] rounded-2xl lg:rounded-3xl -z-10"
              style={{
                opacity: 0,
                animation: 'fadeIn 0.8s var(--ease-smooth) 0.5s forwards',
              }}
            />
          </div>

          {/* Right Column - Content */}
          <div ref={contentRef} className="lg:pl-8">
            {/* Heading */}
            <h2
              className="animate-item text-white mb-8"
              style={{
                opacity: 0,
                transform: 'translateY(50px)',
                transition: 'all 0.6s var(--ease-out-quart)',
              }}
            >
              {heading}
            </h2>

            {/* Paragraphs */}
            <div className="space-y-6 mb-10">
              {paragraphs.map((paragraph, index) => (
                <p
                  key={index}
                  className="animate-item text-[var(--text-secondary)] text-base md:text-lg leading-relaxed"
                  style={{
                    opacity: 0,
                    transform: 'translateY(25px)',
                    transition: `all 0.4s var(--ease-out-quart) ${600 + index * 150}ms`,
                  }}
                >
                  {paragraph}
                </p>
              ))}
            </div>

            {/* CTA Button */}
            <div
              className="animate-item"
              style={{
                opacity: 0,
                transform: 'scale(0.9)',
                transition: 'all 0.4s var(--ease-elastic)',
              }}
            >
              <a
                href={ctaLink}
                className="btn-secondary inline-flex items-center gap-3 group"
              >
                <span>{ctaText}</span>
                <Download
                  size={18}
                  className="transition-transform duration-300 group-hover:translate-y-1"
                />
              </a>
            </div>

            {/* Stats */}
            <div
              className="animate-item grid grid-cols-3 gap-8 mt-12 pt-12 border-t border-[var(--border-subtle)]"
              style={{
                opacity: 0,
                transform: 'translateY(25px)',
                transition: 'all 0.4s var(--ease-out-quart) 1s',
              }}
            >
              {[
                { value: '8+', label: 'Years Experience' },
                { value: '50+', label: 'Projects Completed' },
                { value: '30+', label: 'Happy Clients' },
              ].map((stat, index) => (
                <div key={index} className="text-center lg:text-left">
                  <div className="text-3xl md:text-4xl font-bold text-white mb-1 font-['Melodrama']">
                    {stat.value}
                  </div>
                  <div className="text-sm text-[var(--text-muted)]">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
