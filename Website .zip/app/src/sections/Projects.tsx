import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';
import { ArrowUpRight } from 'lucide-react';

const Projects = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate header
            if (headerRef.current) {
              headerRef.current.style.opacity = '1';
              headerRef.current.style.transform = 'translateY(0)';
            }

            // Animate project cards
            if (gridRef.current) {
              const cards = gridRef.current.querySelectorAll('.project-card');
              cards.forEach((card, i) => {
                setTimeout(() => {
                  (card as HTMLElement).style.opacity = '1';
                  (card as HTMLElement).style.transform = 'translateY(0) scale(1)';
                }, 150 + i * 100);
              });
            }

            observer.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const { heading, subtitle, items } = profileData.projects;

  const featuredProject = items.find((p) => p.featured);
  const otherProjects = items.filter((p) => !p.featured);

  return (
    <section
      ref={sectionRef}
      id="works"
      className="relative w-full py-24 lg:py-32"
      style={{ background: 'var(--bg-primary)' }}
    >
      <div className="relative z-10 w-full section-padding">
        <div className="max-w-[1400px] mx-auto">
          {/* Section Header */}
          <div
            ref={headerRef}
            className="text-center mb-16 lg:mb-20"
            style={{
              opacity: 0,
              transform: 'translateY(30px)',
              transition: 'all 0.5s var(--ease-out-expo)',
            }}
          >
            <h2 className="text-white mb-4">{heading}</h2>
            <p className="text-[var(--text-muted)] text-lg">{subtitle}</p>
          </div>

          {/* Projects Grid */}
          <div ref={gridRef} className="space-y-8 lg:space-y-10">
            {/* Featured Project */}
            {featuredProject && (
              <div
                className="project-card"
                style={{
                  opacity: 0,
                  transform: 'translateY(40px) scale(0.95)',
                  transition: 'all 0.8s var(--ease-out-expo)',
                }}
              >
                <a
                  href={featuredProject.link || '#'}
                  className="group block relative overflow-hidden rounded-2xl lg:rounded-3xl"
                  style={{
                    transform: 'perspective(1000px) rotateX(2deg)',
                    transition: 'all 0.5s ease-out',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'perspective(1000px) rotateX(0deg) scale(1.01)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'perspective(1000px) rotateX(2deg)';
                  }}
                >
                  {/* Image */}
                  <div className="aspect-[2/1] lg:aspect-[21/9] overflow-hidden">
                    <img
                      src={featuredProject.image}
                      alt={featuredProject.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-primary)] via-[var(--bg-primary)]/50 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-500" />

                  {/* Content */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-10">
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <span className="px-3 py-1 rounded-full text-xs font-medium bg-white/10 text-white border border-white/20">
                        Featured
                      </span>
                      <span className="text-sm text-[var(--text-muted)]">
                        {featuredProject.category}
                      </span>
                      <span className="text-sm text-[var(--text-muted)]">
                        {featuredProject.year}
                      </span>
                    </div>
                    <h3 className="text-2xl lg:text-4xl text-white font-['Melodrama'] group-hover:translate-x-2 transition-transform duration-500 flex items-center gap-3">
                      {featuredProject.title}
                      <ArrowUpRight
                        size={24}
                        className="opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0"
                      />
                    </h3>
                  </div>
                </a>
              </div>
            )}

            {/* Other Projects Grid */}
            <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
              {otherProjects.map((project, index) => (
                <div
                  key={index}
                  className="project-card"
                  style={{
                    opacity: 0,
                    transform: `translateY(40px) scale(0.95)`,
                    transition: 'all 0.6s var(--ease-out-quart)',
                  }}
                >
                  <a
                    href={project.link || '#'}
                    className="group block relative overflow-hidden rounded-xl lg:rounded-2xl"
                    style={{
                      transform: 'perspective(800px) rotateX(2deg)',
                      transition: 'all 0.4s ease-out',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'perspective(800px) rotateX(0deg) scale(1.02)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'perspective(800px) rotateX(2deg)';
                    }}
                  >
                    {/* Image */}
                    <div className="aspect-[4/3] overflow-hidden">
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                    </div>

                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-primary)] via-transparent to-transparent opacity-70 group-hover:opacity-90 transition-opacity duration-500" />

                    {/* Content */}
                    <div className="absolute bottom-0 left-0 right-0 p-5 lg:p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-sm text-[var(--text-muted)]">
                          {project.category}
                        </span>
                        <span className="text-sm text-[var(--text-muted)]">
                          {project.year}
                        </span>
                      </div>
                      <h4 className="text-xl lg:text-2xl text-white font-['Melodrama'] flex items-center gap-2">
                        {project.title}
                        <ArrowUpRight
                          size={18}
                          className="opacity-0 group-hover:opacity-100 transition-all duration-300"
                        />
                      </h4>
                    </div>

                    {/* Border Glow on Hover */}
                    <div className="absolute inset-0 rounded-xl lg:rounded-2xl border border-[var(--border-subtle)] group-hover:border-[var(--border-hover)] transition-colors duration-500" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* View All Button */}
          <div
            className="text-center mt-12 lg:mt-16"
            style={{
              opacity: 0,
              animation: 'fadeInUp 0.6s var(--ease-out-quart) 1s forwards',
            }}
          >
            <a href="#" className="btn-secondary inline-flex items-center gap-2 group">
              <span>View All Projects</span>
              <ArrowUpRight
                size={18}
                className="transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1"
              />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
