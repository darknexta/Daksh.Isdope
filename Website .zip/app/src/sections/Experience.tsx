import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';
import { Briefcase } from 'lucide-react';

const Experience = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate header
            if (headerRef.current) {
              headerRef.current.style.opacity = '1';
              headerRef.current.style.transform = 'translateY(0)';
            }

            // Animate timeline
            if (timelineRef.current) {
              setTimeout(() => {
                timelineRef.current!.style.height = '100%';
              }, 200);
            }

            // Animate cards
            if (cardsRef.current) {
              const cards = cardsRef.current.querySelectorAll('.experience-card');
              cards.forEach((card, i) => {
                setTimeout(() => {
                  (card as HTMLElement).style.opacity = '1';
                  (card as HTMLElement).style.transform = 'translateX(0) rotateY(0deg)';
                }, 300 + i * 150);
              });
            }

            observer.disconnect();
          }
        });
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const { heading, subtitle, jobs } = profileData.experience;

  return (
    <section
      ref={sectionRef}
      id="experience"
      className="relative w-full py-24 lg:py-32"
      style={{ background: 'var(--bg-primary)' }}
    >
      <div className="relative z-10 w-full section-padding">
        <div className="max-w-[1000px] mx-auto">
          {/* Section Header */}
          <div
            ref={headerRef}
            className="text-center mb-16 lg:mb-20"
            style={{
              opacity: 0,
              transform: 'translateY(40px)',
              transition: 'all 0.6s var(--ease-out-expo)',
            }}
          >
            <h2 className="text-white mb-4">{heading}</h2>
            <p className="text-[var(--text-muted)] text-lg">{subtitle}</p>
          </div>

          {/* Timeline Container */}
          <div ref={cardsRef} className="relative">
            {/* Timeline Line */}
            <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px md:-translate-x-px">
              <div
                ref={timelineRef}
                className="w-full bg-gradient-to-b from-[var(--border-hover)] via-[var(--border-subtle)] to-transparent"
                style={{
                  height: '0%',
                  transition: 'height 1s var(--ease-out-quart)',
                }}
              />
              {/* Pulse Effect */}
              <div
                className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-white/30"
                style={{
                  animation: 'pulseGlow 3s ease-in-out infinite',
                }}
              />
            </div>

            {/* Experience Cards */}
            <div className="space-y-12 lg:space-y-16">
              {jobs.map((job, index) => (
                <div
                  key={index}
                  className={`experience-card relative flex items-start gap-6 md:gap-8 ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                  style={{
                    opacity: 0,
                    transform: `translateX(${index % 2 === 0 ? '-60px' : '60px'}) rotateY(${index % 2 === 0 ? '10deg' : '-10deg'})`,
                    transition: 'all 0.6s var(--ease-out-expo)',
                  }}
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-4 md:left-1/2 top-0 w-3 h-3 rounded-full bg-white/50 md:-translate-x-1/2 z-10">
                    <div
                      className="absolute inset-0 rounded-full bg-white/30"
                      style={{
                        animation: 'pulseGlow 2s ease-in-out infinite',
                        animationDelay: `${index * 0.3}s`,
                      }}
                    />
                  </div>

                  {/* Spacer for desktop layout */}
                  <div className="hidden md:block md:w-1/2" />

                  {/* Card Content */}
                  <div
                    className={`ml-10 md:ml-0 md:w-1/2 ${
                      index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'
                    }`}
                  >
                    <div
                      className="card-glass group cursor-pointer"
                      style={{
                        transform: 'perspective(800px) rotateX(2deg)',
                        transition: 'all 0.4s ease-out',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'perspective(800px) rotateX(0deg) translateY(-8px)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'perspective(800px) rotateX(2deg)';
                      }}
                    >
                      {/* Company & Period */}
                      <div className="flex flex-wrap items-center gap-3 mb-3">
                        <div className="flex items-center gap-2 text-white font-semibold">
                          <Briefcase size={16} className="text-[var(--text-muted)]" />
                          <span>{job.company}</span>
                        </div>
                        <span className="text-sm text-[var(--text-muted)] px-3 py-1 rounded-full border border-[var(--border-subtle)]">
                          {job.period}
                        </span>
                      </div>

                      {/* Role */}
                      <h4 className="text-xl md:text-2xl text-white mb-3 font-['Melodrama']">
                        {job.role}
                      </h4>

                      {/* Description */}
                      <p className="text-[var(--text-secondary)] text-sm md:text-base leading-relaxed">
                        {job.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
