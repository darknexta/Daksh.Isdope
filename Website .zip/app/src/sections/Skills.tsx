import { useEffect, useRef } from 'react';
import { profileData } from '@/data/profile';
import { Palette, Wrench, Code } from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Design: <Palette size={24} />,
  Tools: <Wrench size={24} />,
  Development: <Code size={24} />,
};

const Skills = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            // Animate header
            if (headerRef.current) {
              headerRef.current.style.opacity = '1';
              headerRef.current.style.transform = 'translateY(0)';
            }

            // Animate cards
            if (cardsRef.current) {
              const cards = cardsRef.current.querySelectorAll('.skill-card');
              cards.forEach((card, i) => {
                setTimeout(() => {
                  (card as HTMLElement).style.opacity = '1';
                  (card as HTMLElement).style.transform = 'translateY(0) scale(1)';
                }, 200 + i * 100);
              });
            }

            observer.disconnect();
          }
        });
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const { heading, subtitle, categories } = profileData.skills;

  return (
    <section
      ref={sectionRef}
      id="skills"
      className="relative w-full py-24 lg:py-32"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Background Gradient */}
      <div
        className="absolute inset-0 opacity-30"
        style={{
          background: `
            radial-gradient(ellipse at 30% 20%, rgba(24, 24, 34, 0.5) 0%, transparent 50%),
            radial-gradient(ellipse at 70% 80%, rgba(15, 15, 26, 0.4) 0%, transparent 50%)
          `,
        }}
      />

      <div className="relative z-10 w-full section-padding">
        <div className="max-w-[1200px] mx-auto">
          {/* Section Header */}
          <div
            ref={headerRef}
            className="text-center mb-16 lg:mb-20"
            style={{
              opacity: 0,
              transform: 'translateY(40px)',
              transition: 'all 0.6s var(--ease-out-expo)',
            }}
          >
            <h2 className="text-white mb-4">{heading}</h2>
            <p className="text-[var(--text-muted)] text-lg">{subtitle}</p>
          </div>

          {/* Skills Grid */}
          <div
            ref={cardsRef}
            className="grid md:grid-cols-3 gap-6 lg:gap-8"
          >
            {categories.map((category, index) => (
              <div
                key={index}
                className="skill-card"
                style={{
                  opacity: 0,
                  transform: 'translateY(40px) scale(0.95)',
                  transition: 'all 0.5s var(--ease-out-expo)',
                }}
              >
                <div
                  className="h-full card-glass p-8 lg:p-10"
                  style={{
                    transform: 'perspective(800px) rotateX(2deg)',
                    transition: 'all 0.4s ease-out',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'perspective(800px) rotateX(0deg) translateY(-8px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'perspective(800px) rotateX(2deg)';
                  }}
                >
                  {/* Icon */}
                  <div className="w-12 h-12 rounded-xl bg-white/5 border border-[var(--border-subtle)] flex items-center justify-center text-white mb-6">
                    {iconMap[category.name] || <Palette size={24} />}
                  </div>

                  {/* Category Name */}
                  <h4 className="text-xl lg:text-2xl text-white mb-6 font-['Melodrama']">
                    {category.name}
                  </h4>

                  {/* Skills List */}
                  <ul className="space-y-3">
                    {category.skills.map((skill, skillIndex) => (
                      <li
                        key={skillIndex}
                        className="flex items-center gap-3 text-[var(--text-secondary)] group"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-white/30 group-hover:bg-white/60 transition-colors duration-300" />
                        <span className="text-sm md:text-base group-hover:text-white transition-colors duration-300">
                          {skill}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>

          {/* Additional Skills Tags */}
          <div
            className="mt-16 text-center"
            style={{
              opacity: 0,
              animation: 'fadeInUp 0.6s var(--ease-out-quart) 0.8s forwards',
            }}
          >
            <p className="text-[var(--text-muted)] mb-6">Also experienced with</p>
            <div className="flex flex-wrap justify-center gap-3">
              {[
                'Motion Design',
                '3D Modeling',
                'Data Visualization',
                'Accessibility',
                'Design Thinking',
                'Agile Methodology',
                'User Testing',
                'A/B Testing',
              ].map((tag, index) => (
                <span
                  key={index}
                  className="px-4 py-2 rounded-full text-sm text-[var(--text-secondary)] border border-[var(--border-subtle)] hover:border-[var(--border-hover)] hover:text-white transition-all duration-300 cursor-default"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
